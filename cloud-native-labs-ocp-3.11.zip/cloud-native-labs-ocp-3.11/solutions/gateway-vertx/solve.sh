##########################
# gateway-vertx Solution #
##########################

DIRECTORY=`dirname $0`

cp $DIRECTORY/*.java $DIRECTORY/../../gateway-vertx/src/main/java/com/redhat/cloudnative/gateway
