################################
# catalog-spring-boot Solution #
################################

DIRECTORY=`dirname $0`

cp $DIRECTORY/*.java $DIRECTORY/../../catalog-spring-boot/src/main/java/com/redhat/cloudnative/catalog